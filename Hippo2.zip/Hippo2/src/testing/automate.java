package testing;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class automate {

	public static void main(String[] args) throws InterruptedException {


		System.setProperty("webdriver.chrome.driver","C:\\Software\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String baseUrl = "https://www.hippovideo.io";
		driver.get(baseUrl);
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");

		WebElement signUp = driver.findElement(By.xpath("//button[@class='btn btn-primary hv-primary-btn signup-dum input-trigger']"));
		signUp.click();

		WebElement email = driver.findElement(By.xpath("//input[@class='form-control email input-trigger']"));
		email.sendKeys("g2@getnada.com");

		WebElement password = driver.findElement(By.xpath("//input[@class='form-control password input-trigger']"));
		password.sendKeys("Test@123");

		WebElement signUpbtn = driver.findElement(By.xpath("//button[@class='btn btn-primary hv-primary-btn f-btn signup-btn']"));
		signUpbtn.click();

		Thread.sleep(5000);
		WebElement business = driver.findElement(By.id("Business-4"));
		business.click();

		List<WebElement> businessList = driver.findElements(By.xpath("//span[@class='plan-button-text']"));
		for (WebElement option : businessList) {
			if(option.getText().equalsIgnoreCase("Personalized marketing campaigns to boost conversions"))
				option.click();   	
		}

		WebElement next = driver.findElement(By.id("Business-next-btn"));
		next.click();

		Thread.sleep(8000);
		WebElement firstNameTxt = driver.findElement(By.id("firstNameTxt"));
		firstNameTxt.sendKeys("First Name");

		WebElement companyNameTxt = driver.findElement(By.id("companyNameTxt"));
		companyNameTxt.sendKeys("Company Name");

		WebElement phoneTxt = driver.findElement(By.id("phoneTxt"));
		phoneTxt.sendKeys("202501956");

		WebElement getStartedBtn = driver.findElement(By.id("saveCompanyName"));
		getStartedBtn.click();

		Thread.sleep(6000);
		WebElement plusIcon = driver.findElement(By.xpath("//section[@class='flt_right import_nav']/div[@id='ly_20000000004']"));
		plusIcon.click();

		WebElement createCategory = driver.findElement(By.xpath("//section[@data-name='Create video _+']"));
		createCategory.click();



		// driver.close();
	}
}
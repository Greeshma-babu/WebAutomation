package pageObject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class pageObject {

	@FindBy(xpath="//button[@class='btn btn-primary hv-primary-btn signup-dum input-trigger']")
	public static WebElement signUp;
	
	@FindBy(xpath="//input[@class='form-control email input-trigger']")
	public static WebElement email;
	
	@FindBy(xpath="//input[@class='form-control password input-trigger']")
	public static WebElement password;
	
	@FindBy(xpath="//button[@class='btn btn-primary hv-primary-btn f-btn signup-btn']")
	public static WebElement signUpbtn;
	
	@FindBy(id="Business-4")
	public static WebElement business;
	
	@FindBy(xpath="//span[@class='plan-button-text']")
	public static List<WebElement> businessList;
	
	@FindBy(id="Business-next-btn")
	public static WebElement next;
	
	@FindBy(id="firstNameTxt")
	public static WebElement firstNameTxt;
	
	@FindBy(id="companyNameTxt")
	public static WebElement companyNameTxt;
	
	@FindBy(id="phoneTxt")
	public static WebElement phoneTxt;
	
	@FindBy(id="saveCompanyName")
	public static WebElement getStartedBtn;
	
	@FindBy(xpath="//section[@class='flt_right import_nav']/div[@id='ly_20000000004']")
	public static WebElement plusIcon;
	
	@FindBy(xpath="//section[@data-name='Create video _+']")
	public static WebElement createCategory;
	
	@FindBy(xpath="//div[@class='small-12 columns text-center']/a[@class='wiz-button-outline']")
	public static WebElement createVideo;
	
}

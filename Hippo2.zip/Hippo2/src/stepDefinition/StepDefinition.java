package stepDefinition;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.Page;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.pageObject;

public class StepDefinition extends Page{


	@Given("go to this URL")
	public void go_to_this_URL() throws IOException {
		getURL();

	}

	@When("click on SignUp button and enter valid email and password in that field")
	public void click_on_SignUp_button_and_enter_valid_email_and_password_in_that_field() {
		enterEmailPassword();
	}

	@Then("click on Business plan")
	public void click_on_Business_plan() throws InterruptedException {
		clickOnBusiness();

	}

	@Then("select Personalized marketing campaigns to boost conversions")
	public void select_Personalized_marketing_campaigns_to_boost_conversions() {
		selectPersonalizedMarketingCampaignsToBoostConversions();

	}

	@Then("click on Next button")
	public void click_on_Next_button() {
		clickOnNext();

	}

	@Then("Enter FirstName,CompanyName and Phonenumber")
	public void enter_FirstName_CompanyName_and_Phonenumber() throws InterruptedException {
		enterDetails();
	}

	@Then("click on GetStarted button")
	public void click_on_GetStarted_button() {
		clickOnGetStarted();

	}

	@Then("click on plus icon")
	public void click_on_plus_icon() throws InterruptedException {
		clickOnPlus();
	}

	@Then("click on Create Video")
	public void click_on_Create_Video() {
		clickOnCreateVideo();

	}

	@Then("Record Video and add personalization and send email")
	public void record_Video_and_add_personalization_and_send_email() throws InterruptedException {
		createVideo();
	}

	@Then("After sending mail, check video in your email and Validate the Video Personalization")
	public void after_sending_mail_check_video_in_your_email_and_Validate_the_Video_Personalization() {
		// Write code here that turns the phrase above into concrete actions
		throw new cucumber.api.PendingException();
	}




}

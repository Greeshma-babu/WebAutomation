//package utility.config;
//
//import java.util.Properties;
//
//import com.aventstack.extentreports.ExtentReports;
//
//public class ConfigFileReader {
//
////	public String getReportConfigPath(){
////		Properties prop = new Properties();
////		 String reportConfigPath = prop.getProperty("reportConfigPath");
////		 if(reportConfigPath!= null) return reportConfigPath;
////		 else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath"); 
////	}
//	
//	@BeforeClass
//	public static void startTest()
//	{
//		Properties prop = new Properties();
//		String reportConfigPath = prop.getProperty("reportConfigPath");
//	report = new ExtentReports();
//	test = report.startTest("ExtentDemo");
//	}
//	@Test
//	public void extentReportsDemo()
//	{
//	System.setProperty("webdriver.chrome.driver", "D:\\SubmittalExchange_TFS\\QA\\Automation\\3rdparty\\chrome\\chromedriver.exe");
//	WebDriver driver = new ChromeDriver();
//	driver.get("https://www.google.co.in");
//	if(driver.getTitle().equals("Google"))
//	{
//	test.log(LogStatus.PASS, "Navigated to the specified URL");
//	}
//	else
//	{
//	test.log(LogStatus.FAIL, "Test Failed");
//	}
//	}
//	@AfterClass
//	public static void endTest()
//	{
//	report.endTest(test);
//	report.flush();
//	}
//	}
//}
//
//
//
//

package Page;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import pageObject.pageObject;
import utility.config.ExtentReportsClass;

public class Page extends ExtentReportsClass{


	WebDriver driver;
	File file = new File(System.getProperty("user.dir")+"/src/utility/config/Configuration.properties");
	Properties prop = new Properties();
	FileInputStream  input;
	ExtentReports report;
	ExtentTest test;
	
	@Test
	public void getURL() throws IOException {
		System.setProperty("webdriver.chrome.driver","C:\\Software\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		input = new FileInputStream(file);
		prop.load(input);
		String baseUrl = prop.getProperty("URL");
		driver.get(baseUrl);
		driver.manage().window().maximize();
		PageFactory.initElements(driver, pageObject.class);
	}

	@Test
	public void enterEmailPassword(){

		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");

		pageObject.signUp.click();
		pageObject.email.sendKeys(prop.getProperty("email"));
		pageObject.password.sendKeys(prop.getProperty("password"));
		pageObject.signUpbtn.click();
	}

	@Test
	public void clickOnBusiness() throws InterruptedException {
		Thread.sleep(5000);
		pageObject.business.click();
	}

	public void selectPersonalizedMarketingCampaignsToBoostConversions() {
		List<WebElement> businessList = pageObject.businessList;
		for (WebElement option : businessList) {
			if(option.getText().equalsIgnoreCase("Personalized marketing campaigns to boost conversions"))
				option.click();
		}
	}
	public void clickOnNext() {
		pageObject.next.click();
	}

	public void enterDetails() throws InterruptedException {
		Thread.sleep(8000);
		pageObject.firstNameTxt.sendKeys(prop.getProperty("firstName"));
		pageObject.companyNameTxt.clear();
		pageObject.companyNameTxt.sendKeys(prop.getProperty("companyName"));
		pageObject.phoneTxt.sendKeys(prop.getProperty("phoneNumber"));
	}
	public void clickOnGetStarted() {
		pageObject.getStartedBtn.click();
	}

	public void clickOnPlus() throws InterruptedException {
		Thread.sleep(8000);
		pageObject.plusIcon.click();
	}

	public void clickOnCreateVideo() {
		pageObject.createCategory.click();
		
	}
	
	public void createVideo() throws InterruptedException {
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,700)");
		pageObject.createVideo.click();
		driver.close();
	}
	
}
